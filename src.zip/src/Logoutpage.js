import React from 'react'

function Logoutpage() {
  return (
    <div>You have been Loged-out</div>
  )
}

export default Logoutpage